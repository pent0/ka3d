Hi all,

Here's a small patch to ode-0.5 which I thought somebody else might find useful too: It changes ODE and OPCODE to use MSVC debug memory allocation functions, and maps OPCODE's new/delete to those functions. Shouldn't do any harm on non-MSVC platforms either: http://www.pixelgene.com/jani/ode-0.5-msvc-dbgmalloc-patch.zip

As most allocations go through objects.h it's usefulness is a bit limited, but it can give some useful information too, at least you can tell the difference which leak is from your stuff, which from ODE and which from OPCODE.

For example while testing it I found out that 'new dxTriMeshData' in dGeomTriMeshDataCreate doesn't go through dBase allocation functions (I guess it should) and when using triangle mesh, ode leaks memory as one OPCODE's IceContainer doesn't get freed properly (due to static variables in triangle mesh impl).

Install: Copy StdAfx.h over OPCODE's StdAfx.h, and memory.h to include/ode and memory.cpp ode/src.


Regards,
Jani
